
#include <project.h>

CY_ISR (Push_Psoc_Handler)
{
   int i=0;
    while(i<8){
        i++;
        CyDelay(500);
        output_1_Write(1);
    }
    output_1_Write(0);
    CyDelay(500);
    Push_Psoc_ClearInterrupt();
    
}

CY_ISR (Push_button_Handler)
{
   int i=0;
    while(i<8){
        i++;
        CyDelay(500);
        output_2_Write(1);
    }
    output_2_Write(0);
    CyDelay(500);
    Push_button_ClearInterrupt();
    
}

CY_ISR (LDR_Handler)
{
   int i=0;
    while(i<8){
    
        i++;
        CyDelay(500);
        output_3_Write(1);
        
    }
    output_3_Write(0);
    CyDelay(500);
    LDR_ClearInterrupt();
    
}
int main()
{

    CyGlobalIntEnable;
    inter_1_StartEx(Push_Psoc_Handler);
    inter_2_StartEx(Push_button_Handler);
    inter_3_StartEx(LDR_Handler);
    
    for(;;)
    {
        
    }
}
